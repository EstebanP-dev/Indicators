# ICommandBase

Es una clase base usada para identificar a los tipo [ICommand](Icommand.md).

```csharp
/// <summary>
/// <see cref="ICommand"/> and <seealso cref="ICommand{TResponse}"/> base interface.
/// </summary>
public interface ICommandBase
{
}
```
