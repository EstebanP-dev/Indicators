# Abstracciones

Estas son clases abstractas o interfaces que van directamente relacionada a la lógica del negocio o casos de uso.

## Elementos

- [Data](./data/data.md).
- [Messaging](./messaging/messaging.md).
- [IJwtProvider](IjwtProvider.md).
- [IPasswordHasher](IpasswordHasher.md).
