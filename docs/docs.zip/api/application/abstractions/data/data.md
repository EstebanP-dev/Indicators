# Data

Es una carpeta que contiene todo lo relacionado a los datos de la base de datos, del lado de la lógica del negocio o casos de uso.

## Elementos

- [IApplicationDbContext](IapplicationDbContext.md).
