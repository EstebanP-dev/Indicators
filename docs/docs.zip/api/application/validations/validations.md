# Validations

Actualmente no se encuentran implementas, pero pronto se espera.
