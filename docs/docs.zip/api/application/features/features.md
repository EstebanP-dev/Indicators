# Features

En esta carpeta se encuentran agrupados los comandos y consultas de cada entidad de la base de datos. En esa se aloja toda la lógica y casos de uso.

## Elementos

- [Users](./users/users.md).