# Commands

Los comandos con transacciones que se realizan con la db.

## Elementos

- [Crear usuario](./createUser.md).

**NOTA:** La lógica del comando y la consulta, alica para cualquier otro de la misma clase.
