# Queries

Son consultas a la base de datos. El obtener de datos se separa debido a que no requieren una carga de logica o control muy alta. Por el contrario, estas en su mayoria requieren una manipulación de los datos, donde pasan por varios modelos o conjunto de consultas.

## Elementos

- [GetUserById](getUserById.md).
