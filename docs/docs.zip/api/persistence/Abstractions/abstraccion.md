# Abstraccions

Las abstracciones de la capa de persistencia, son implementaciones de interfaces compartidas de applicación (en su gran mayoria).

## Elementos

- [Repository](repository.md).
