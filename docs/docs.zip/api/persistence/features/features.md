# Features

En esta carpeta se aloja la lógica de [Persistence](./../persistence.md) separada por entidades.

## Elementos

- [Users](./users/users.md).
