# Users

Esta carpeta contiene las implementaciones de [Persistencia](./../../persistence.md) para la entidad [User](./../../../domain/entities/user.md).

## Elementos

- [UserConfiguration](userConfiguration.md).
- [UserRepository](userRepository.md).
