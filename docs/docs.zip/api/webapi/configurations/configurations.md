# Configurations

Es esta carpeta encontraremos las cargas de dependencias dela app separadas por utilidades o caracteristicas en común. Es decir, las clases de [Aplicación](./../../application/application.md) estarán en una clase **ApplicationInstaller**. Cada librería en su documentación especifica como realizar su implementación en el proyecto y si es necesario registrarlar en los servicios.

## Elementos

- [IServiceInstaller](./IserviceInstaller.md).
- [ApplicationConfiguration](./applicationConfiguration.md).
