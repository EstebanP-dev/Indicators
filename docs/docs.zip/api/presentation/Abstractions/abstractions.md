# Abstracciones

Estas son clases abstractas o interfaces que van directamente relacionada al controlador.

## Elementos

- [BaseModule](baseModule.md).
