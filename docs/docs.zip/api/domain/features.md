# Features

Es una estructura de carpetas que encapsulan la logica relacionada a la entidad. Dentro de esta se encuentra el modelo, el repositorio y el Id. Estos features tambien se pueden agrupar si estos comparten caracteristicas, como es el caso de la entidad *Section (Sección)* y *SubSection (Subsección)*.
