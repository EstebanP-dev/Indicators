# Entitidades

La estructura de las entidades se mantiene a diferencia de la primary key, la cual la abtraeremos a una clase aparte.


## Elementos

- [UserId](userId.md).
- [User Entity](user.md).

La misma estructura se replica en las demás entidades. Generamos los demás campos basados en la base de datos.
