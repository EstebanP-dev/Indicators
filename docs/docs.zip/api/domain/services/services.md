# Services

Es una carpeta que contiene servicios basados en la identidad del negocio. Estos servicios, pese a que puedan llegar de terceros, son relacionados con el dominio del negocio o las entidades, es por esto que se ubican en el [Dominio](./../domain.md) y no en [Applicación](./../../application/application.md).

## Elementos

- [IPasswordHashChecker](./IpasswordHashChecker.md).
