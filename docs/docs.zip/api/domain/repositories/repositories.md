# Repositories

Esta carpeta contiene las interfaces, de repositorios compartidos, que se implementaran en la capa de [Persistencia](./../../persistence/persistence.md).

## Elementos
- [IRepository](Irepository.md).
- [IUnitOfWork](IunitOfWork.md).