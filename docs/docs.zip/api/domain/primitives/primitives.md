
# Primitives

Los objeetos primitivos, son clases que tienen un funcionamiento abstracto, es decir, buscan que otras clases hereden sus comportamientos.

## Elementos

- [Entity{T}](entityT.md).
- [Value Object](valueObject.md).
- [Pagination](pagination.md).
- [Pagination Query Parameters](paginationQueryParameters.md).
