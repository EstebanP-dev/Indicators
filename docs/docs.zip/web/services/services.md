# Services

En esta carpeta se guardaran los llamados al api o cualquier otro servicio de la app. El mismo formato aplica para todos.

## Elementos

- [Displays](displays.md).
