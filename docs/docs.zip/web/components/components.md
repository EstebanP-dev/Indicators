# Componentes

En esta carpeta se almacenan los componentes compartidos de las vistas. Los componenetes son pequeñas porciones de código **TSX** y **Scss**.

## Elementos

- [Data Table](datatable.md).
