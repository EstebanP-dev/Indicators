# Modelos

En esta carpeta encontraremos los modelos, basados en lo que nos entrega el api.

## Elementos

- [Error](error.md).
- [Axios Call](axiosCall.md).
- [Account Info](accountInfo.md).

**NOTA:**

- En esta carpeta, se almacenan todos los modelos que la aplicación necesite.
