# Error

Este modelo mapea las peticiones con error que retorna el api.

```ts
export interface Error{
    status: number;
    message: string;
}
```
