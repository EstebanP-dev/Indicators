# Account Info

Este modelo mapea la petición del servicio de Login.

```ts
export interface AccountInfo {
    token: string;
    user: User;
}
```
