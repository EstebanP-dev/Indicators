# Redux

En esta carpeta, almacenamos las clases para el control de estados del proyecto con ayuda de la libreria [Redux](https://redux.js.org/).

## Elementos

- [Store](store.md).
- [Status](./status/status.md).
